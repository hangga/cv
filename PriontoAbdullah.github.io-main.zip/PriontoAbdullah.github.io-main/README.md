## Live - [Prionto's Portfolio](https://prionto-71.web.app/)

Role : Front End Developer | Full Stack Developer | MERN stack Developer

#### Features :

- Responsive UI
- Single Page Application (SPA)
- User can see all the information about Prionto Adbullah and give a feedback.
- User can see Prionto's Project in the website
- User can also Read Prionto's blog via this protfolio

#### Technologies :

● Aos, Styled-Component, Framer Motion, Swiper, React Spring, React Reveal etc
● ReactJS, React-Router, React Bootsrap, React Scroll, HTML5, CSS3, Bootstrap4, JS, Git, etc.

![github-large](https://i.ibb.co/nnzr04z/prionto-71-web-app.png)
