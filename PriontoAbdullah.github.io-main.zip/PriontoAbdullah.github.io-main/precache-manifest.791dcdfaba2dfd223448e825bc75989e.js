self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6d5d3abada465f5fd85840caebb49e19",
    "url": "/index.html"
  },
  {
    "revision": "a89023be7bacde1dbc6e",
    "url": "/static/css/2.be1420b5.chunk.css"
  },
  {
    "revision": "d910a6b054239fa27315",
    "url": "/static/css/main.1f22edee.chunk.css"
  },
  {
    "revision": "a89023be7bacde1dbc6e",
    "url": "/static/js/2.df07ec27.chunk.js"
  },
  {
    "revision": "ef49b20b99ae1858aa836926d6fcce95",
    "url": "/static/js/2.df07ec27.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d910a6b054239fa27315",
    "url": "/static/js/main.0fc61f07.chunk.js"
  },
  {
    "revision": "fac124cdfb88d06aba47",
    "url": "/static/js/runtime-main.9f990208.js"
  },
  {
    "revision": "8e728fd20788c403f852911676a5c266",
    "url": "/static/media/bg.8e728fd2.png"
  },
  {
    "revision": "7b4c380782373d8d855a4cf8058a85fa",
    "url": "/static/media/bootstrap.7b4c3807.png"
  },
  {
    "revision": "88eef2c4956cf1d9ffbb00a2059d9dd6",
    "url": "/static/media/c-programming.88eef2c4.png"
  },
  {
    "revision": "5aed309804308db40397f2f897d4812c",
    "url": "/static/media/choromeDev.5aed3098.png"
  },
  {
    "revision": "92931bf3fd42fffb9de652f007014d1e",
    "url": "/static/media/css.92931bf3.png"
  },
  {
    "revision": "adf1f3252150b5793133096be67d29be",
    "url": "/static/media/ecmascript6.adf1f325.png"
  },
  {
    "revision": "b62fd8079b2613ac5d65ff9341d5def2",
    "url": "/static/media/expressjs.b62fd807.png"
  },
  {
    "revision": "efb492c008a5b83f435c9ce86a52d496",
    "url": "/static/media/figma.efb492c0.png"
  },
  {
    "revision": "c24b6b9c0fcd84c7b258879880472660",
    "url": "/static/media/firebase.c24b6b9c.png"
  },
  {
    "revision": "15f93a2f5b3d077b42db0b1631ee5f63",
    "url": "/static/media/graphQL.15f93a2f.png"
  },
  {
    "revision": "454a400ca987d4271e54045982ea3876",
    "url": "/static/media/html.454a400c.png"
  },
  {
    "revision": "9f0a24d5365dae42b6fa42ce8df8ab7b",
    "url": "/static/media/js.9f0a24d5.png"
  },
  {
    "revision": "a5f506f9d44be21fbf5510a7927d5713",
    "url": "/static/media/logo.a5f506f9.png"
  },
  {
    "revision": "978c1206351057ee2291ff205e349109",
    "url": "/static/media/meta.978c1206.png"
  },
  {
    "revision": "28ec40a4d2332648f920ff506571a7d7",
    "url": "/static/media/mongodb.28ec40a4.png"
  },
  {
    "revision": "b24f0f3d08ae1a9e59cc47b38f5d7a36",
    "url": "/static/media/mongoose.b24f0f3d.png"
  },
  {
    "revision": "07c28adf28e0592b46094aef81fcc655",
    "url": "/static/media/mysql.07c28adf.png"
  },
  {
    "revision": "661bf8729d3a972ccbb4ce469600aa7a",
    "url": "/static/media/nextjs.661bf872.png"
  },
  {
    "revision": "abecfc00bf6bd0b3ca16a0ed53ce903d",
    "url": "/static/media/nodejs.abecfc00.png"
  },
  {
    "revision": "0cfd04ae89be38d7614bf6b90ecd6dc2",
    "url": "/static/media/npm.0cfd04ae.png"
  },
  {
    "revision": "21f17516a2daa47f0ba1afdd30ef6d4f",
    "url": "/static/media/prionto.21f17516.png"
  },
  {
    "revision": "3b2bc36c80af942fa84bcb1659457414",
    "url": "/static/media/priontoFull.3b2bc36c.png"
  },
  {
    "revision": "72cccc0c8463452f23e6007e7f1c0b1c",
    "url": "/static/media/react-native.72cccc0c.png"
  },
  {
    "revision": "b7bf6c6596e103d1bf0a8e2f8d398a7a",
    "url": "/static/media/react.b7bf6c65.png"
  },
  {
    "revision": "42ac80a30bf7d652fb4edfd8b078fd66",
    "url": "/static/media/reactstrap.42ac80a3.png"
  },
  {
    "revision": "8251fe76d7487a28b07603515b300964",
    "url": "/static/media/redux.8251fe76.png"
  },
  {
    "revision": "dd2714a1d0761050a6dc29099fa0ba55",
    "url": "/static/media/sass.dd2714a1.png"
  },
  {
    "revision": "505f3eed90a32f9107adbcde6428d5b4",
    "url": "/static/media/slack.505f3eed.png"
  },
  {
    "revision": "e0c2e25d2918fb58b67e0b74811e9aa3",
    "url": "/static/media/tailwind.e0c2e25d.png"
  },
  {
    "revision": "1f5d1f797fc3110a0559f11b3e4bc16c",
    "url": "/static/media/vs-code.1f5d1f79.png"
  },
  {
    "revision": "9330813202fdb028bdedc605ee8fb0b3",
    "url": "/static/media/webpack.93308132.png"
  },
  {
    "revision": "11ee0136f84a2adab32468db6ca81eec",
    "url": "/static/media/wordpress.11ee0136.png"
  }
]);