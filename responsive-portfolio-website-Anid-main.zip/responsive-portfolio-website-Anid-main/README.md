# Responsive Portfolio Website Anid
## [Watch it on youtube](https://youtu.be/qxxanKFR7js)
### Responsive Portfolio Website Anid

- Responsive Portfolio Website Using HTML CSS And JavaScript
- Contains animations when scrolling.
- Smooth scrolling in each section.
- Contains a beautiful dark theme.
- The color of the project can be customized.
- Custom cursor & animated shapes.
- Slide-out projects, tabbed sections, & a copy email button.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
